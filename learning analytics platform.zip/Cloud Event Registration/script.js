// Load events on home page
async function loadEvents() {

    const eventsContainer =
        document.getElementById("events");

    if (!eventsContainer) return;

    try {

        const response =
            await fetch("/api/events");

        const events =
            await response.json();

        if (events.length === 0) {

            eventsContainer.innerHTML =
                "<p>No events available.</p>";

            return;
        }

        eventsContainer.innerHTML =
            events.map(event => `

                <div class="event-card">

                    <h3>${event.name}</h3>

                    <p>
                        ${event.description}
                    </p>

                    <p>
                        📅 ${event.date}
                    </p>

                    <p>
                        📍 ${event.venue}
                    </p>

                    <p>
                        👥 Seats: ${event.seats}
                    </p>

                    <button
                        onclick="registerEvent('${event.name}')">

                        Register Now

                    </button>

                </div>

            `).join("");

    } catch (error) {

        eventsContainer.innerHTML =
            "<p>Unable to load events.</p>";
    }
}


// Open registration page
function registerEvent(eventName) {

    localStorage.setItem(
        "selectedEvent",
        eventName
    );

    window.location.href =
        "register.html";
}


// Load events into registration dropdown
async function loadRegistrationEvents() {

    const eventSelect =
        document.getElementById("event");

    if (!eventSelect) return;

    try {

        const response =
            await fetch("/api/events");

        const events =
            await response.json();

        events.forEach(event => {

            const option =
                document.createElement("option");

            option.value = event.name;

            option.textContent = event.name;

            eventSelect.appendChild(option);

        });

        const selectedEvent =
            localStorage.getItem("selectedEvent");

        if (selectedEvent) {

            eventSelect.value =
                selectedEvent;

            localStorage.removeItem(
                "selectedEvent"
            );
        }

    } catch (error) {

        console.log(error);
    }
}


// Student registration
const registrationForm =
    document.getElementById("registrationForm");

if (registrationForm) {

    registrationForm.addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();

            const data = {

                name:
                    document.getElementById(
                        "name"
                    ).value,

                email:
                    document.getElementById(
                        "email"
                    ).value,

                phone:
                    document.getElementById(
                        "phone"
                    ).value,

                college:
                    document.getElementById(
                        "college"
                    ).value,

                event:
                    document.getElementById(
                        "event"
                    ).value
            };

            try {

                const response =
                    await fetch(
                        "/api/register",
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json"
                            },

                            body:
                                JSON.stringify(data)
                        }
                    );

                const result =
                    await response.json();

                document.getElementById(
                    "message"
                ).textContent =
                    result.message;

                registrationForm.reset();

            } catch (error) {

                document.getElementById(
                    "message"
                ).textContent =
                    "Registration failed.";
            }

        }
    );
}


// Add new event
const eventForm =
    document.getElementById("eventForm");

if (eventForm) {

    eventForm.addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();

            const data = {

                name:
                    document.getElementById(
                        "eventName"
                    ).value,

                description:
                    document.getElementById(
                        "eventDescription"
                    ).value,

                date:
                    document.getElementById(
                        "eventDate"
                    ).value,

                venue:
                    document.getElementById(
                        "eventVenue"
                    ).value,

                seats:
                    document.getElementById(
                        "eventSeats"
                    ).value
            };

            try {

                const response =
                    await fetch(
                        "/api/events",
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json"
                            },

                            body:
                                JSON.stringify(data)
                        }
                    );

                const result =
                    await response.json();

                document.getElementById(
                    "eventMessage"
                ).textContent =
                    result.message;

                eventForm.reset();

                loadRegistrations();

            } catch (error) {

                document.getElementById(
                    "eventMessage"
                ).textContent =
                    "Error adding event.";
            }

        }
    );
}


// Load registrations
async function loadRegistrations() {

    const container =
        document.getElementById(
            "registrations"
        );

    if (!container) return;

    try {

        const response =
            await fetch(
                "/api/registrations"
            );

        const registrations =
            await response.json();

        if (registrations.length === 0) {

            container.innerHTML =
                "<p>No registrations yet.</p>";

            return;
        }

        container.innerHTML =
            registrations.map(reg => `

                <div class="registration-card">

                    <strong>
                        ${reg.name}
                    </strong>

                    <p>
                        📧 ${reg.email}
                    </p>

                    <p>
                        📱 ${reg.phone}
                    </p>

                    <p>
                        🎓 ${reg.college}
                    </p>

                    <p>
                        🎫 Event:
                        ${reg.event}
                    </p>

                    <button
                        onclick="deleteRegistration('${reg._id}')">

                        Delete

                    </button>

                </div>

            `).join("");

    } catch (error) {

        container.innerHTML =
            "<p>Unable to load registrations.</p>";
    }
}


// Delete registration
async function deleteRegistration(id) {

    if (!confirm(
        "Delete this registration?"
    )) {
        return;
    }

    try {

        await fetch(
            `/api/registrations/${id}`,
            {
                method: "DELETE"
            }
        );

        loadRegistrations();

    } catch (error) {

        alert("Delete failed.");
    }
}


// Run functions
loadEvents();
loadRegistrationEvents();
loadRegistrations();